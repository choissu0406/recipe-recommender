# Auto-generated from data_exploration.ipynb (same cells). Run: python data_exploration.py

try:
    display
except NameError:
    def display(x):
        print(x.to_string() if hasattr(x, "to_string") else x)


# # Final Project Task 1 — Data Exploration
# **Dataset:** 식품의약품안전처 「조리식품의 레시피 DB」 (식품안전나라 Open API, 서비스 ID `COOKRCP01`)
# **Service idea:** 보유 재료를 입력하면 재료 일치율을 계산해 만들 수 있는 레시피를 추천
# 
# 실행 전 `README.md`의 안내대로 `data/` 폴더에 JSON 파일 2개를 준비하거나, 환경변수 `FOODSAFETY_API_KEY`를 설정하세요.

# ## 0. Setup

import os, json, re, urllib.request
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager

pd.set_option('display.max_columns', 30)
pd.set_option('display.width', 160)

# 한글 폰트: 설치된 것 중 첫 번째를 사용 (Windows / macOS / Linux)
for f in ['Malgun Gothic', 'AppleGothic', 'NanumGothic', 'Noto Sans CJK KR', 'Noto Sans KR']:
    if any(f == x.name for x in font_manager.fontManager.ttflist):
        plt.rcParams['font.family'] = f
        break
plt.rcParams['axes.unicode_minus'] = False

DATA_DIR = 'data'
OUT_DIR = 'outputs'
os.makedirs(OUT_DIR, exist_ok=True)

# ## 1. Load data
# API는 한 번에 최대 1,000건까지 반환하므로 1–1000, 1001–2000 두 번 호출해 저장한 파일을 합친다.
# 로컬 파일이 없고 API 키가 있으면 API에서 직접 받아 `data/`에 저장한다.

FILES = [('recipes_1_1000.json', 1, 1000), ('recipes_1001_2000.json', 1001, 2000)]

def fetch(start, end, key):
    url = f'https://openapi.foodsafetykorea.go.kr/api/{key}/COOKRCP01/json/{start}/{end}'
    with urllib.request.urlopen(url, timeout=60) as r:
        return json.loads(r.read().decode('utf-8'))

rows, total_count = [], None
os.makedirs(DATA_DIR, exist_ok=True)
for fname, s, e in FILES:
    path = os.path.join(DATA_DIR, fname)
    if not os.path.exists(path):
        key = os.environ.get('FOODSAFETY_API_KEY')
        if not key:
            raise FileNotFoundError(f'{path} 가 없습니다. README.md 를 참고해 파일을 받거나 FOODSAFETY_API_KEY 를 설정하세요.')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(fetch(s, e, key), f, ensure_ascii=False)
    with open(path, encoding='utf-8') as f:
        payload = json.load(f)['COOKRCP01']
    print(fname, payload['RESULT'], 'rows =', len(payload['row']))
    total_count = int(payload['total_count'])
    rows += payload['row']

raw = pd.DataFrame(rows)
print('API total_count =', total_count, '| loaded =', len(raw))
assert len(raw) == total_count

# ## 2. Profile: size, columns, types, sample records
# 레코드 1건 = 레시피 1개. API는 모든 값을 문자열로 반환하고 빈 값은 `''`로 준다 → `NaN`으로 바꾸고 영양 성분은 숫자로 변환한다.

df = raw.replace('', np.nan).copy()
NUM = {'INFO_ENG': '열량(kcal)', 'INFO_CAR': '탄수화물(g)', 'INFO_PRO': '단백질(g)',
       'INFO_FAT': '지방(g)', 'INFO_NA': '나트륨(mg)'}
for c in NUM:
    df[c] = pd.to_numeric(df[c], errors='coerce')
df['RCP_SEQ'] = pd.to_numeric(df['RCP_SEQ'])

manual_cols = [c for c in df.columns if re.fullmatch(r'MANUAL\d\d', c)]
img_cols = [c for c in df.columns if c.startswith('MANUAL_IMG')]
df['n_steps'] = df[manual_cols].notna().sum(axis=1)

print('shape:', raw.shape)
print('MANUAL01-20 (조리 단계 텍스트):', len(manual_cols), '| MANUAL_IMG01-20 (단계 이미지):', len(img_cols))
key_cols = ['RCP_SEQ', 'RCP_NM', 'RCP_PAT2', 'RCP_WAY2', 'RCP_PARTS_DTLS', 'INFO_WGT',
            *NUM.keys(), 'HASH_TAG', 'RCP_NA_TIP', 'ATT_FILE_NO_MAIN', 'n_steps']
display(df[key_cols].dtypes.to_frame('dtype').T)

display(df[['RCP_SEQ', 'RCP_NM', 'RCP_PAT2', 'RCP_WAY2', 'INFO_ENG', 'INFO_NA', 'n_steps']].head(5))
print(df.loc[0, 'RCP_NM'], '→ RCP_PARTS_DTLS:')
print(df.loc[0, 'RCP_PARTS_DTLS'])
print('\nRCP_SEQ range:', df.RCP_SEQ.min(), '~', df.RCP_SEQ.max(), '(일련번호가 연속적이지 않음; 날짜 필드는 없음)')

# ## 3. Missing values and duplicates

miss = df[key_cols].isna().sum().to_frame('missing')
miss['rate_%'] = (miss['missing'] / len(df) * 100).round(1)
display(miss[miss.missing > 0].sort_values('missing', ascending=False))

# 재료 텍스트가 사실상 비어 있는 경우 (예: '.')
bad_parts = df.RCP_PARTS_DTLS.isna() | (df.RCP_PARTS_DTLS.str.strip().str.len() < 3)
print('재료 정보 없음/무의미:', bad_parts.sum())

dup_seq = df.RCP_SEQ.duplicated().sum()
dup_name = df.RCP_NM.duplicated(keep=False)
dup_exact = df.duplicated(subset=['RCP_NM', 'RCP_PARTS_DTLS'], keep='first')
print('RCP_SEQ 중복:', dup_seq)
print('같은 메뉴명이 2번 이상 나오는 레코드:', dup_name.sum(), f'({df[dup_name].RCP_NM.nunique()}개 메뉴명)')
print('메뉴명+재료가 완전히 같은 중복(제거 대상):', dup_exact.sum())
display(df[dup_name].sort_values('RCP_NM')[['RCP_SEQ', 'RCP_NM', 'RCP_PAT2', 'INFO_ENG']])

# ## 4. Descriptive statistics and category distributions

display(df[list(NUM)].rename(columns=NUM).describe().round(1))
print('값이 0인 영양 성분이 하나라도 있는 레시피:', (df[list(NUM)] == 0).any(axis=1).sum())
display(pd.concat([df.RCP_PAT2.value_counts().rename('요리종류(RCP_PAT2)'),
                   df.RCP_WAY2.value_counts().rename('조리방법(RCP_WAY2)')], axis=1).fillna(0).astype(int))

# ## 5. Data-quality issue A — 영양 성분 값의 일관성
# 열량은 대략 `4×탄수화물 + 4×단백질 + 9×지방`(Atwater 계수)과 비슷해야 한다.
# 비율이 0.5–1.5 범위를 벗어나면 단위 오류·입력 오류 가능성이 높은 레코드로 표시한다.

df['kcal_from_macros'] = 4 * df.INFO_CAR + 4 * df.INFO_PRO + 9 * df.INFO_FAT
df['kcal_ratio'] = df.kcal_from_macros / df.INFO_ENG.replace(0, np.nan)
flag = (df.kcal_ratio < 0.5) | (df.kcal_ratio > 1.5) | df.kcal_ratio.isna()
print('ratio median =', round(df.kcal_ratio.median(), 3))
print(f'일관성 실패 레코드: {flag.sum()} / {len(df)} ({flag.mean()*100:.1f}%)')
print('  ratio < 0.5:', (df.kcal_ratio < 0.5).sum(), '| ratio > 1.5:', (df.kcal_ratio > 1.5).sum(),
      '| 열량 0:', (df.INFO_ENG == 0).sum())
display(df.loc[flag].sort_values('kcal_ratio', ascending=False)
          [['RCP_SEQ', 'RCP_NM', *NUM.keys(), 'kcal_ratio']].head(8).round(2))
df['nutrition_ok'] = ~flag

# ## 6. Data-quality issue B — 재료 텍스트(RCP_PARTS_DTLS)의 비정형성
# 서비스의 핵심 필드인데 형식이 레코드마다 다르다:
# `연두부 75g(3/4모)`, `바게트(1/4개)`, `●주재료 : 딸기 100g`, `[ 2인분 ] 마늘(4쪽)`, 첫 줄에 메뉴명 반복 등.
# 아래 파서는 괄호 안의 쉼표를 보존하면서 나누고, 섹션 라벨·수량·단위를 제거해 **재료명 리스트**를 만든다 (Task 1용 1차 버전).

LABELS = {'재료', '주재료', '부재료', '양념', '양념장', '소스', '고명', '육수', '드레싱', '반죽',
          '소', '기타', '양념재료', '장식', '토핑', '곁들임', '절임물', '조림장', '필링', '시럽'}
UNIT = r'(g|kg|ml|mL|L|l|cc|개|큰술|작은술|컵|장|쪽|줌|모|마리|대|봉지|톨|알|뿌리|줄기|송이|cm|Ts|ts|T|t|인분)'

def split_top(s):
    """쉼표/줄바꿈으로 나누되 괄호 안의 쉼표는 무시"""
    out, buf, depth = [], '', 0
    for ch in s:
        if ch in '([{': depth += 1
        elif ch in ')]}': depth = max(depth - 1, 0)
        if ch in ',\n' and depth == 0:
            out.append(buf); buf = ''
        else:
            buf += ch
    out.append(buf)
    return out

def clean_token(t, recipe_name):
    t = re.sub(r'^\[[^\]]*\]', '', t.strip()).strip()        # [ 2인분 ]
    t = re.sub(r'^[●•·\-\*]+', '', t).strip()
    m = re.match(r'^([가-힣 ]{1,6})\s*[:：]\s*(.*)$', t)       # '주재료 : 딸기'
    if m: t = m.group(2).strip()
    p = t.split(' ', 1)
    if len(p) == 2 and p[0] in LABELS: t = p[1]                # '재료 바나나(150g)'
    t = re.sub(r'\([^)]*\)|\[[^\]]*\]', ' ', t)               # 괄호 내용
    t = t.split('+')[0]
    t = re.sub(r'[\d½⅓⅔¼¾⅛/.~×xX]+\s*' + UNIT + '?', ' ', t)   # 수량 + 단위
    t = re.sub(r'(약간|조금|적당량|적량|소량)', ' ', t)
    t = re.sub(r'[^가-힣a-zA-Z ]', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    if not t or t in LABELS or len(t) > 15: return None
    if t.replace(' ', '') == str(recipe_name).replace(' ', ''): return None  # 메뉴명 반복 줄
    return t

def parse_ingredients(s, name):
    if not isinstance(s, str): return []
    out = []
    for t in split_top(s):
        t = clean_token(t, name)
        if t and t not in out: out.append(t)
    return out

df['ingredients_raw'] = [parse_ingredients(s, n) for s, n in zip(df.RCP_PARTS_DTLS, df.RCP_NM)]
for i in [0, 300, 1100]:
    print(df.RCP_NM[i], '→', df.ingredients_raw[i])

cnt_raw = Counter(i for L in df.ingredients_raw for i in L)
print('파싱 후 고유 재료명 수:', len(cnt_raw))
# 같은 재료가 여러 이름으로 기록되는 문제 (표기 불일치)
for group in [['마늘', '다진 마늘', '다진마늘', '간 마늘', '깐마늘'],
              ['후춧가루', '후추'], ['올리브유', '올리브오일'], ['달걀', '계란'],
              ['간장', '저염간장', '진간장']]:
    print({g: cnt_raw.get(g, 0) for g in group})

# 1차 정규화: 공백 제거 + 동의어/가공형 표기를 대표명으로 통합 (Task 2에서 확장 예정)
SYN = {'다진마늘': '마늘', '간마늘': '마늘', '깐마늘': '마늘', '편마늘': '마늘', '통마늘': '마늘', '마늘다진것': '마늘',
       '후추': '후춧가루', '흰후추': '후춧가루', '올리브오일': '올리브유', '계란': '달걀', '달걀노른자': '달걀', '달걀흰자': '달걀',
       '저염간장': '간장', '진간장': '간장', '국간장': '간장', '양조간장': '간장', '저염된장': '된장',
       '다진파': '대파', '파': '대파', '쪽파': '실파', '홍고추': '고추', '청고추': '고추', '청양고추': '고추',
       '식용유': '식용유', '포도씨유': '식용유', '카놀라유': '식용유', '물엿': '올리고당', '참깨': '깨', '통깨': '깨',
       '소금적당량': '소금', '천일염': '소금', '꽃소금': '소금'}

def normalize(name):
    k = name.replace(' ', '')
    return SYN.get(k, k)

df['ingredients'] = df.ingredients_raw.apply(lambda L: sorted({normalize(x) for x in L}))
df['n_ingr'] = df.ingredients.str.len()
cnt = Counter(i for L in df.ingredients for i in L)
print('정규화 후 고유 재료명 수:', len(cnt), f'(정규화 전 {len(cnt_raw)})')
print('재료가 1개 이하로 파싱된 레시피:', (df.n_ingr <= 1).sum())

# ## 7. Preliminary EDA — summary table (요리종류별)

clean = df[~dup_exact].copy()   # 완전 중복 제거
summary = (clean.groupby('RCP_PAT2')
           .agg(recipes=('RCP_SEQ', 'size'),
                median_ingredients=('n_ingr', 'median'),
                median_steps=('n_steps', 'median'),
                median_kcal=('INFO_ENG', lambda s: s[clean.loc[s.index, 'nutrition_ok']].median()),
                median_sodium_mg=('INFO_NA', lambda s: s[clean.loc[s.index, 'nutrition_ok']].median()),
                nutrition_flag_pct=('nutrition_ok', lambda s: (1 - s.mean()) * 100))
           .sort_values('recipes', ascending=False).round(1))
display(summary)
summary.to_csv(os.path.join(OUT_DIR, 'summary_by_category.csv'), encoding='utf-8-sig')

# ## 8. Preliminary EDA — 재료 커버리지와 '보유 재료' 시뮬레이션
# ※ 아래 빈도는 **해당 재료가 들어가는 레시피 수**(카탈로그 내 등장 빈도)이지 인기도가 아니다.
# 서비스 관점 질문: 자취생이 기본 양념 + 주재료 몇 개를 갖고 있을 때 실제로 만들 수 있는 레시피는 몇 개인가?

BASIC = {'소금', '설탕', '간장', '식용유', '참기름', '후춧가루', '물', '마늘', '깨', '고춧가루'}  # 가정한 기본 양념
MAINS = {'달걀', '양파', '두부', '대파'}                                                 # 예시 사용자 주재료
pantry = BASIC | MAINS

def match(recipe_ingr, have):
    if not recipe_ingr: return np.nan, np.nan
    hit = len(set(recipe_ingr) & have)
    return hit / len(recipe_ingr), len(recipe_ingr) - hit

usable = clean[clean.n_ingr >= 2].copy()
usable[['match_rate', 'n_missing']] = usable.ingredients.apply(lambda L: pd.Series(match(L, pantry)))
sim = pd.DataFrame({
    '조건': ['재료 100% 보유', '부족 재료 ≤ 1개', '부족 재료 ≤ 2개', '일치율 ≥ 50%'],
    '레시피 수': [(usable.n_missing == 0).sum(), (usable.n_missing <= 1).sum(),
                (usable.n_missing <= 2).sum(), (usable.match_rate >= 0.5).sum()]})
sim['비율_%'] = (sim['레시피 수'] / len(usable) * 100).round(1)
print('분석 대상 레시피:', len(usable), '| pantry =', sorted(pantry))
display(sim)
display(usable.sort_values(['n_missing', 'match_rate'], ascending=[True, False])
        [['RCP_NM', 'RCP_PAT2', 'n_ingr', 'n_missing', 'match_rate']].head(8).round(2))

fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), gridspec_kw={'width_ratios': [1.15, 1]})

top = pd.Series(Counter(i for L in clean.ingredients for i in L)).sort_values(ascending=False).head(15)[::-1]
colors = ['#c8553d' if k in BASIC else '#2a6f97' for k in top.index]
axes[0].barh(top.index, top.values / len(clean) * 100, color=colors)
axes[0].set_xlabel('포함 레시피 비율 (%)')
axes[0].set_title('(a) 가장 많은 레시피에 들어가는 재료 Top 15\n(주황 = 기본 양념으로 가정한 재료)', fontsize=11)
for y, v in enumerate(top.values / len(clean) * 100):
    axes[0].text(v + 0.4, y, f'{v:.0f}', va='center', fontsize=8)

order = summary.index.tolist()
data = [clean.loc[clean.RCP_PAT2 == k, 'n_ingr'] for k in order]
axes[1].boxplot(data, showfliers=False)
axes[1].set_xticks(range(1, len(order) + 1), order)
axes[1].set_ylabel('레시피당 재료 수 (정규화 후)')
axes[1].set_title('(b) 요리종류별 필요한 재료 수 분포', fontsize=11)
for ax in axes:
    ax.spines[['top', 'right']].set_visible(False)
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, 'fig_ingredients.png'), dpi=200)
plt.show()

# ## 9. Notes for Task 2
# - 완전 중복 제거, 영양 성분 일관성 실패 레코드는 영양 정보 표시에서 제외하거나 '확인 필요'로 표시
# - 재료 정규화 사전(SYN) 확장, 섹션 라벨이 붙은 토큰(예: '비트 드레싱 발사믹식초') 분리 규칙 보완
# - 기본 양념을 '보유 가정' 옵션으로 둘지 사용자 선택으로 둘지 결정
