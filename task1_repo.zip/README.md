# Final Project Task 1 — Data Exploration

보유 재료 기반 레시피 추천 서비스를 위한 데이터 탐색 코드입니다.

## Dataset
- **이름:** 조리식품의 레시피 DB (`COOKRCP01`)
- **제공:** 식품의약품안전처, 식품안전나라 Open API
- **안내 페이지:** https://www.foodsafetykorea.go.kr/api/openApiInfo.do?svc_no=COOKRCP01
- **공공데이터포털:** https://www.data.go.kr/data/15060073/openapi.do
- **규모:** 레시피 1,156건(API `total_count`), 55개 필드, 2026-11-19 수집
- **이용 조건:** 무료 인증키(자동 승인)가 필요하고, 키 1개당 호출 수 제한이 있습니다. 데이터 이용 조건은 위 페이지를 확인하세요.

이 저장소에는 원본 데이터 JSON을 올리지 않습니다. 아래 방법으로 직접 받아 주세요.

## 데이터 받기
1. 식품안전나라(또는 공공데이터포털)에서 로그인한 뒤 `COOKRCP01` 인증키를 발급받습니다.
2. 아래 두 방법 중 하나를 고릅니다.
   - **(A) 자동:** 환경변수에 키를 넣고 노트북을 실행하면 `data/` 폴더에 파일이 저장됩니다.
     ```bash
     export FOODSAFETY_API_KEY=발급받은키      # Windows PowerShell: $env:FOODSAFETY_API_KEY="발급받은키"
     ```
   - **(B) 수동:** 브라우저에서 아래 주소를 열고, 각각 `data/recipes_1_1000.json`, `data/recipes_1001_2000.json`으로 저장합니다.
     ```
     https://openapi.foodsafetykorea.go.kr/api/{KEY}/COOKRCP01/json/1/1000
     https://openapi.foodsafetykorea.go.kr/api/{KEY}/COOKRCP01/json/1001/2000
     ```

## 실행
```bash
pip install pandas numpy matplotlib jupyter
jupyter notebook data_exploration.ipynb   # 또는: python data_exploration.py
```
실행하면 `outputs/` 폴더에 다음 파일이 만들어집니다.
- `summary_by_category.csv`: 요리종류별 요약표
- `fig_ingredients.png`: 재료 커버리지와 요리종류별 재료 수 그래프

## 파일 구성
| 파일 | 내용 |
|---|---|
| `data_exploration.ipynb` | 로드 → 프로파일 → 결측·중복 → 품질 이슈(영양 일관성, 재료 텍스트 파싱) → EDA → 보유 재료 시뮬레이션 |
| `data_exploration.py` | 노트북과 같은 코드를 스크립트로 실행하는 버전 |
| `.gitignore` | `data/` 폴더를 커밋하지 않도록 제외 |
